#ifndef LAMEPLAYER_H_
#define LAMEPLAYER_H_

class LamePlayer
{
public:
	LamePlayer();
	virtual ~LamePlayer();
};

#endif /* LAMEPLAYER_H_ */

