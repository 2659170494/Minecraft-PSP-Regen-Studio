#include "DirectionBlock.h"


DirectionBlock::DirectionBlock(int x, int y, int z, char dir)
{
    X = x;
    Z = z;
    Y = y;

    direction = dir;
}

DirectionBlock::~DirectionBlock()
{

}

