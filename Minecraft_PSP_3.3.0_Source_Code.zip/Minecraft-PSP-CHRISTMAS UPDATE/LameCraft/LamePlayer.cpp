#include "LamePlayer.h"

LamePlayer::LamePlayer()
{
	// TODO Auto-generated constructor stub

}

LamePlayer::~LamePlayer()
{
	// TODO Auto-generated destructor stub
}
