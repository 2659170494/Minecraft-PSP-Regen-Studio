#include "Mobs.h"

Zombie::Zombie(float x, float y, float z) : LameMob(x, y, z)
{
    collideBox.x = 0.5f;
    collideBox.y = 1.9f;
    collideBox.x = 0.5f;
}
