#ifndef MOBS_H_
#define MOBS_H_

#include "LameMob.h"

class Zombie : public LameMob
{
public:

Zombie(float x, float y, float z);

};

#endif /* MOBS_H_ */

